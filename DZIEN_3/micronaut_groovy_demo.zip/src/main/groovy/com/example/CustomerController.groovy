
package com.example

import io.micronaut.http.MediaType
import io.micronaut.http.annotation.*

@Controller("/customers")
class CustomerController {

    private List<Map> customers = [
            [id: 1, name: "Marcin", city: "Kraków"],
            [id: 2, name: "Ewa",    city: "Warszawa"]
    ]

    @Get("/")
    List<Map> list() {
        customers
    }

    @Get("/{id}")
    Map get(Long id) {
        customers.find { it.id == id }
    }

    @Post(value = "/", consumes = MediaType.APPLICATION_JSON)
    Map add(@Body Map data) {
        data.id = (customers*.id.max() ?: 0) + 1
        customers << data
        data
    }
}
