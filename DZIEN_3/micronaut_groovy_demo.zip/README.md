
# Micronaut + Groovy Demo

Prosty projekt Micronaut w Groovy do pokazu na szkoleniu.

## Jak uruchomić

1. Wejdź do katalogu projektu:

   ```bash
   cd micronaut_groovy_demo
   ```

2. Uruchom aplikację:

   ```bash
   ./gradlew run
   ```

3. Przetestuj endpointy:

   - `GET http://localhost:8080/hello`
   - `GET http://localhost:8080/customers`
   - `GET http://localhost:8080/customers/1`
   - `POST http://localhost:8080/customers` z JSON-em, np.:

     ```json
     {
       "name": "Adam",
       "city": "Gdańsk"
     }
     ```
