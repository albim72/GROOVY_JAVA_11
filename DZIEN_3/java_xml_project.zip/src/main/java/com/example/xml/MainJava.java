package com.example.xml;

import java.nio.file.Path;
import java.util.List;

public class MainJava {
    public static void main(String[] args) {
        XmlServiceJava service = new XmlServiceJava();
        Path inPath = Path.of("people.xml");
        Path outPath = Path.of("people_copy.xml");

        try {
            System.out.println("--- ODCZYT XML (Java) ---");
            List<Person> people = service.readPeople(inPath);
            people.forEach(System.out::println);

            System.out.println("--- ZAPIS XML (Java) ---");
            service.writePeople(outPath, people);
            System.out.println("Zapisano do: " + outPath);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
