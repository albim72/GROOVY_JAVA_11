package com.example.xml;

import org.w3c.dom.*;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;

public class XmlServiceJava {

    public List<Person> readPeople(Path path) throws Exception {
        List<Person> people = new ArrayList<>();

        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();

        try (var in = Files.newInputStream(path)) {
            Document doc = builder.parse(in);
            doc.getDocumentElement().normalize();

            NodeList nodes = doc.getElementsByTagName("person");
            for (int i = 0; i < nodes.getLength(); i++) {
                Node node = nodes.item(i);
                if (node.getNodeType() == Node.ELEMENT_NODE) {
                    Element e = (Element) node;

                    String name = getText(e, "name");
                    int age = Integer.parseInt(getText(e, "age"));
                    String city = getText(e, "city");

                    people.add(new Person(name, age, city));
                }
            }
        }
        return people;
    }

    private String getText(Element parent, String tagName) {
        NodeList list = parent.getElementsByTagName(tagName);
        if (list.getLength() == 0) return "";
        return list.item(0).getTextContent();
    }

    public void writePeople(Path path, List<Person> people) throws Exception {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document doc = builder.newDocument();

        Element root = doc.createElement("people");
        doc.appendChild(root);

        for (Person p : people) {
            Element personEl = doc.createElement("person");

            Element nameEl = doc.createElement("name");
            nameEl.setTextContent(p.getName());
            personEl.appendChild(nameEl);

            Element ageEl = doc.createElement("age");
            ageEl.setTextContent(String.valueOf(p.getAge()));
            personEl.appendChild(ageEl);

            Element cityEl = doc.createElement("city");
            cityEl.setTextContent(p.getCity());
            personEl.appendChild(cityEl);

            root.appendChild(personEl);
        }

        TransformerFactory tf = TransformerFactory.newInstance();
        Transformer transformer = tf.newTransformer();
        transformer.setOutputProperty(OutputKeys.INDENT, "true");

        try (var out = Files.newOutputStream(path)) {
            transformer.transform(new DOMSource(doc), new StreamResult(out));
        }
    }
}
