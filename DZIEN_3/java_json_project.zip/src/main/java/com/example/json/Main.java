
package com.example.json;

import java.nio.file.Path;

public class Main {
    public static void main(String[] args) {
        JsonService service = new JsonService();
        Path path = Path.of("people.json");

        try {
            System.out.println("--- RAW JSON READ ---");
            String json = service.readRaw(path);
            System.out.println(json);

            System.out.println("--- RAW JSON WRITE ---");
            service.writeRaw(Path.of("people_copy.json"), json);

            System.out.println("Saved to people_copy.json");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
