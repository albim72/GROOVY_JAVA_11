
package com.example.json;

import java.nio.file.*;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

public class JsonService {

    public String readRaw(Path path) throws IOException {
        return Files.readString(path);
    }

    public void writeRaw(Path path, String content) throws IOException {
        Files.writeString(path, content);
    }
}
